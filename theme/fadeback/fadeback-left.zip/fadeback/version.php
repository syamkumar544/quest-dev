<?php

defined('MOODLE_INTERNAL') || die;

$plugin->version   = 2012080901;
$plugin->component = 'theme_fadeback';
$plugin->requires  = 2011070101;
$plugin->maturity  = MATURITY_STABLE;